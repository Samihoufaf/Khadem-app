# Khadem MVP

نسخة أولية قابلة للتطوير لتطبيق يربط الزبائن بالخدامين.

## التشغيل
1. ثبت Flutter.
2. افتح هذا المجلد.
3. شغل:
   flutter pub get
   flutter run

## الموجود حاليًا
- Splash / Onboarding
- اختيار زبون أو خدام
- Home للزبون
- بحث بالـAI (واجهة تجريبية)
- قائمة خدامين
- Profile للخدام
- إرسال طلب وحالة الطلب
- طلبات/رسائل/حساب
- Home وطلب للخدام

## الخطوات التالية
- Firebase أو Supabase
- OTP حقيقي
- GPS وخرائط
- Backend
- OpenAI/Gemini API
- Chat وPush Notifications
- توثيق الخدامين
- نظام تقييم
- Admin Dashboard
- الدفع الإلكتروني لاحقًا
